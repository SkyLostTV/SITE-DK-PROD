import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get(api.photos.list.path, async (req, res) => {
    const category = req.query.category as string | undefined;
    const photos = await storage.getPhotos(category);
    res.json(photos);
  });

  app.get(api.photos.get.path, async (req, res) => {
    const photo = await storage.getPhoto(Number(req.params.id));
    if (!photo) {
      return res.status(404).json({ message: 'Photo not found' });
    }
    res.json(photo);
  });

  app.post(api.photos.create.path, async (req, res) => {
    try {
      const input = api.photos.create.input.parse(req.body);
      const photo = await storage.createPhoto(input);
      res.status(201).json(photo);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
        });
      }
      throw err;
    }
  });

  // Seed Data
  seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existing = await storage.getPhotos();
  if (existing.length === 0) {
    console.log("Seeding database with initial photos...");
    
    // Le Mans 2025 Seed Data (Using high quality race car placeholders)
    const lemansPhotos = [
      {
        title: "Hypercar Dawn",
        description: "The leading hypercar catching the first rays of sunlight at the Dunlop curve.",
        url: "https://images.unsplash.com/photo-1594535182308-8ff2489c085e?q=80&w=2000&auto=format&fit=crop",
        category: "lemans-2025",
        location: "Circuit de la Sarthe"
      },
      {
        title: "Pit Lane Intensity",
        description: "Mechanics performing a lightning-fast tire change during the night stint.",
        url: "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?q=80&w=2000&auto=format&fit=crop",
        category: "lemans-2025",
        location: "Pit Lane"
      },
      {
        title: "Mulsanne Straight Speed",
        description: "Capturing the raw speed on the legendary straight.",
        url: "https://images.unsplash.com/photo-1552176625-e47ff529b595?q=80&w=2000&auto=format&fit=crop",
        category: "lemans-2025",
        location: "Mulsanne Straight"
      },
      {
        title: "Sunset GT3 Battle",
        description: "GT3 cars fighting for position as the sun sets over the circuit.",
        url: "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?q=80&w=2000&auto=format&fit=crop",
        category: "lemans-2025",
        location: "Porsche Curves"
      },
       {
        title: "Night Racing",
        description: "Glowing brake discs and headlights cutting through the darkness.",
        url: "https://images.unsplash.com/photo-1627454820574-fb66fa970b80?q=80&w=2000&auto=format&fit=crop",
        category: "lemans-2025",
        location: "Tertre Rouge"
      }
    ];

    // Retro Mobile 2026 Seed Data (Classic cars)
    const retroPhotos = [
      {
        title: "Vintage 911",
        description: "A perfectly restored classic 911 on display.",
        url: "https://images.unsplash.com/photo-1503376763036-066120622c74?q=80&w=2000&auto=format&fit=crop",
        category: "retromobile-2026",
        location: "Paris Expo Porte de Versailles"
      },
      {
        title: "Classic Chrome",
        description: "Details of a 1950s American classic.",
        url: "https://images.unsplash.com/photo-1485291571150-772bcfc10da5?q=80&w=2000&auto=format&fit=crop",
        category: "retromobile-2026",
        location: "Main Hall"
      },
      {
        title: "Racing Legend",
        description: "A historic race car that competed in the 1960s.",
        url: "https://images.unsplash.com/photo-1532906619279-a79815c32750?q=80&w=2000&auto=format&fit=crop",
        category: "retromobile-2026",
        location: "Hall 1"
      },
      {
        title: "Italian Masterpiece",
        description: "Curves of a rare Italian sports car.",
        url: "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?q=80&w=2000&auto=format&fit=crop",
        category: "retromobile-2026",
        location: "Auction Area"
      },
      {
        title: "Engine Detail",
        description: "The heart of a classic V12 engine.",
        url: "https://images.unsplash.com/photo-1536700503339-1e4b06520771?q=80&w=2000&auto=format&fit=crop",
        category: "retromobile-2026",
        location: "Technical Showcase"
      }
    ];

    for (const photo of [...lemansPhotos, ...retroPhotos]) {
      await storage.createPhoto(photo);
    }
    console.log("Database seeded successfully!");
  }
}
