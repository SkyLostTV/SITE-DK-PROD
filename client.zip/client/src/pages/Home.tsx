import { Hero } from "@/components/Hero";
import { usePhotos } from "@/hooks/use-photos";
import { PhotoCard } from "@/components/PhotoCard";
import { Link } from "wouter";
import { ArrowRight, Calendar, Trophy, History } from "lucide-react";
import { useState } from "react";
import Lightbox from "yet-another-react-lightbox";
import "yet-another-react-lightbox/styles.css";

export default function Home() {
  const { data: featuredPhotos } = usePhotos(); // In real app, might filter by 'featured'
  const [index, setIndex] = useState(-1);

  // Take first 6 photos for the preview grid
  const previewPhotos = featuredPhotos?.slice(0, 6) || [];

  return (
    <div className="min-h-screen bg-background">
      <Hero />

      {/* Featured Events Section */}
      <section className="py-24 bg-background relative">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-16">
            
            {/* Le Mans Card */}
            <div className="group relative h-[500px] overflow-hidden rounded-sm cursor-pointer border border-white/5">
              {/* Le Mans placeholder */}
              <div 
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                style={{ backgroundImage: `url('https://pixabay.com/get/ge3110cf0d6f1e8fe7bf4143cceec14b043eef6f859e61fac9c9cc186c5beecd8a54f314c94b873fb03752da4f07e2ee305c4af5b0f0771e9a5d06f398dc1fe14_1280.jpg')` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
              
              <div className="absolute bottom-0 left-0 p-8 md:p-12">
                <div className="flex items-center gap-2 text-primary font-bold uppercase tracking-wider text-sm mb-4">
                  <Trophy className="w-4 h-4" />
                  <span>June 2025</span>
                </div>
                <h2 className="text-4xl font-display font-bold text-white mb-4 leading-none">
                  24h Le Mans
                </h2>
                <p className="text-gray-300 mb-8 max-w-md line-clamp-3">
                  The ultimate test of man and machine. Experience the night stints, the glowing brakes, and the sunrise at the Circuit de la Sarthe through my lens.
                </p>
                <Link href="/gallery/lemans-2025" className="inline-flex items-center gap-2 text-white font-bold uppercase tracking-widest border-b-2 border-primary pb-1 hover:text-primary transition-colors">
                  View Collection <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

            {/* Retro Mobile Card */}
            <div className="group relative h-[500px] overflow-hidden rounded-sm cursor-pointer border border-white/5">
              {/* Classic car placeholder */}
              <div 
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                style={{ backgroundImage: `url('https://images.unsplash.com/photo-1469037784699-75dcff1cbf75?q=80&w=2070&auto=format&fit=crop')` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
              
              <div className="absolute bottom-0 left-0 p-8 md:p-12">
                <div className="flex items-center gap-2 text-primary font-bold uppercase tracking-wider text-sm mb-4">
                  <History className="w-4 h-4" />
                  <span>February 2026</span>
                </div>
                <h2 className="text-4xl font-display font-bold text-white mb-4 leading-none">
                  Rétromobile
                </h2>
                <p className="text-gray-300 mb-8 max-w-md line-clamp-3">
                  A celebration of automotive history. Capturing the timeless elegance of classic icons, rare prototypes, and the stories they carry.
                </p>
                <Link href="/gallery/retromobile-2026" className="inline-flex items-center gap-2 text-white font-bold uppercase tracking-widest border-b-2 border-primary pb-1 hover:text-primary transition-colors">
                  View Collection <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Latest Work Grid */}
      <section className="py-24 bg-neutral-900/30">
        <div className="container mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div>
              <span className="text-primary font-bold uppercase tracking-widest text-sm block mb-2">Portfolio</span>
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white">Latest Captures</h2>
            </div>
            <Link href="/gallery/all" className="hidden md:flex items-center gap-2 text-gray-400 hover:text-white transition-colors uppercase tracking-wider text-sm">
              View All Photos <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {previewPhotos.map((photo, i) => (
              <PhotoCard 
                key={photo.id} 
                photo={photo} 
                index={i} 
                onClick={() => setIndex(i)} 
              />
            ))}
          </div>
          
          <div className="mt-12 text-center md:hidden">
            <Link href="/gallery/all" className="inline-block px-8 py-3 border border-white/20 text-white font-bold uppercase tracking-widest">
              View All Photos
            </Link>
          </div>
        </div>
      </section>

      {/* Stats/Info Section */}
      <section className="py-24 border-y border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-20 opacity-5 pointer-events-none">
          <Calendar className="w-96 h-96 text-white" />
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div className="p-6">
              <span className="block text-5xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-white/20 mb-4">50+</span>
              <p className="text-gray-400 uppercase tracking-widest text-sm">Races Covered</p>
            </div>
            <div className="p-6 border-l border-r border-white/5">
              <span className="block text-5xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-white/20 mb-4">10k+</span>
              <p className="text-gray-400 uppercase tracking-widest text-sm">Photos Taken</p>
            </div>
            <div className="p-6">
              <span className="block text-5xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-white/20 mb-4">2025</span>
              <p className="text-gray-400 uppercase tracking-widest text-sm">Upcoming Season</p>
            </div>
          </div>
        </div>
      </section>

      {/* Lightbox */}
      <Lightbox
        open={index >= 0}
        index={index}
        close={() => setIndex(-1)}
        slides={previewPhotos.map(p => ({ src: p.url, title: p.title, description: p.description }))}
      />
    </div>
  );
}
