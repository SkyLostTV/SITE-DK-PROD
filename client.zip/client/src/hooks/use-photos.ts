import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertPhoto, type Photo } from "@shared/schema";

export function usePhotos(category?: string) {
  const queryKey = category 
    ? [api.photos.list.path, category] 
    : [api.photos.list.path];

  return useQuery({
    queryKey,
    queryFn: async () => {
      const url = category 
        ? `${api.photos.list.path}?category=${category}` 
        : api.photos.list.path;
        
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch photos");
      return api.photos.list.responses[200].parse(await res.json());
    },
  });
}

export function usePhoto(id: number) {
  return useQuery({
    queryKey: [api.photos.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.photos.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch photo");
      return api.photos.get.responses[200].parse(await res.json());
    },
  });
}

// Keep the create mutation available even if not exposed in public UI yet
export function useCreatePhoto() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertPhoto) => {
      const res = await fetch(api.photos.create.path, {
        method: api.photos.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create photo");
      return api.photos.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.photos.list.path] });
    },
  });
}
