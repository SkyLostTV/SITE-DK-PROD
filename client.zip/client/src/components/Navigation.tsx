import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { Menu, X, Camera } from "lucide-react";
import { useState } from "react";

export function Navigation() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: "Portfolio", path: "/" },
    { name: "Le Mans 2025", path: "/gallery/lemans-2025" },
    { name: "Rétromobile 2026", path: "/gallery/retromobile-2026" },
    { name: "About", path: "/about" },
  ];

  const isActive = (path: string) => {
    if (path === "/" && location !== "/") return false;
    return location.startsWith(path);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-white/5">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="p-2 bg-primary rounded-lg group-hover:bg-red-600 transition-colors">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-lg leading-none tracking-widest">
                SPEED<span className="text-primary">LENS</span>
              </span>
              <span className="text-[10px] text-muted-foreground uppercase tracking-[0.2em]">
                Automotive Art
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path} className="relative group py-2">
                <span className={cn(
                  "text-sm font-medium uppercase tracking-wider transition-colors hover:text-primary",
                  isActive(item.path) ? "text-primary" : "text-muted-foreground"
                )}>
                  {item.name}
                </span>
                {isActive(item.path) && (
                  <motion.div
                    layoutId="underline"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"
                  />
                )}
              </Link>
            ))}
            <Link href="/contact" className="px-5 py-2 bg-white text-black text-sm font-bold uppercase tracking-wider hover:bg-gray-200 transition-colors rounded-sm">
              Contact
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2 text-white"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden absolute top-20 left-0 right-0 bg-black/95 border-b border-white/10 p-4 backdrop-blur-xl"
        >
          <div className="flex flex-col space-y-4">
            {navItems.map((item) => (
              <Link 
                key={item.path} 
                href={item.path} 
                onClick={() => setIsOpen(false)}
                className={cn(
                  "text-lg font-display uppercase tracking-wider p-2 hover:text-primary transition-colors",
                  isActive(item.path) ? "text-primary border-l-2 border-primary pl-4" : "text-muted-foreground"
                )}
              >
                {item.name}
              </Link>
            ))}
            <Link 
              href="/contact" 
              onClick={() => setIsOpen(false)}
              className="mt-4 block w-full text-center py-3 bg-primary text-white font-bold uppercase tracking-wider"
            >
              Get in Touch
            </Link>
          </div>
        </motion.div>
      )}
    </header>
  );
}
