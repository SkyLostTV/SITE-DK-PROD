import { z } from 'zod';
import { insertPhotoSchema, photos } from './schema';

export const errorSchemas = {
  notFound: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  photos: {
    list: {
      method: 'GET' as const,
      path: '/api/photos',
      input: z.object({
        category: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof photos.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/photos/:id',
      responses: {
        200: z.custom<typeof photos.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    // For this portfolio, we'll keep it read-only for public, 
    // but in a real app you'd want auth for these:
    create: {
      method: 'POST' as const,
      path: '/api/photos',
      input: insertPhotoSchema,
      responses: {
        201: z.custom<typeof photos.$inferSelect>(),
      },
    }
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
