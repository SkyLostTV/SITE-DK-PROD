## Packages
yet-another-react-lightbox | Premium lightbox experience for the photo gallery
framer-motion | For immersive page transitions and scroll animations (already in base, but emphasizing usage)

## Notes
- Images will use high-quality Unsplash placeholders since the actual events (2025/2026) haven't happened yet.
- The design focuses on a dark, "cinematic" aesthetic suitable for automotive photography.
- Routes are setup for Le Mans 2025 and Rétromobile 2026 specific galleries.
