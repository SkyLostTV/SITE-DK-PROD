import { motion } from "framer-motion";
import { Camera, Award, Clock } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background pt-32 pb-24">
      <div className="container mx-auto px-4">
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-primary font-bold uppercase tracking-widest text-sm mb-4 block">The Photographer</span>
            <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-8">
              BEHIND <br /> THE LENS
            </h1>
            <div className="space-y-6 text-gray-300 text-lg font-light leading-relaxed">
              <p>
                Photography is not just about capturing light; it's about freezing emotion, speed, and history in a single frame.
              </p>
              <p>
                Specializing in automotive photography, I travel to the world's most prestigious circuits and concourses. From the grueling 24 hours of Le Mans to the refined elegance of Rétromobile Paris, my goal is to document the soul of the machine.
              </p>
              <p>
                The 2025/2026 season represents a new chapter—a fusion of modern hypercar technology and the timeless beauty of classic motoring.
              </p>
            </div>
            
            <div className="mt-12 grid grid-cols-3 gap-8">
              <div>
                <Camera className="w-8 h-8 text-primary mb-4" />
                <h3 className="text-white font-bold uppercase tracking-wider mb-2">Gear</h3>
                <p className="text-sm text-gray-400">Sony Alpha System<br />Prime Lenses</p>
              </div>
              <div>
                <Award className="w-8 h-8 text-primary mb-4" />
                <h3 className="text-white font-bold uppercase tracking-wider mb-2">Awards</h3>
                <p className="text-sm text-gray-400">Intl. Motor Press<br />Finalist 2023</p>
              </div>
              <div>
                <Clock className="w-8 h-8 text-primary mb-4" />
                <h3 className="text-white font-bold uppercase tracking-wider mb-2">Experience</h3>
                <p className="text-sm text-gray-400">10+ Years<br />Trackside</p>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-primary/20 transform translate-x-4 translate-y-4" />
            <img 
              src="https://pixabay.com/get/gf772169d4878993edede0021976f9be6290df326ba0ce7748668eb7f6c2740917ccfc64c1045999609833dc2a72709a96989ae53620b0c6cb070fafdb521158a_1280.jpg" 
              alt="Photographer at work" 
              className="relative w-full aspect-[4/5] object-cover grayscale hover:grayscale-0 transition-all duration-700"
            />
          </motion.div>
        </div>

      </div>
    </div>
  );
}
