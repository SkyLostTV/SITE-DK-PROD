import { useParams } from "wouter";
import { usePhotos } from "@/hooks/use-photos";
import { PhotoCard } from "@/components/PhotoCard";
import { useState } from "react";
import Lightbox from "yet-another-react-lightbox";
import "yet-another-react-lightbox/styles.css";
import { categories } from "@shared/schema";
import { Loader2, Camera } from "lucide-react";
import { motion } from "framer-motion";

export default function Gallery() {
  const { categoryId } = useParams();
  const { data: photos, isLoading, error } = usePhotos(categoryId === 'all' ? undefined : categoryId);
  const [index, setIndex] = useState(-1);

  // Find category info for header
  const categoryInfo = categories.find(c => c.id === categoryId);
  const title = categoryInfo ? categoryInfo.name : (categoryId === 'all' ? 'Full Archive' : 'Gallery');
  const description = categoryInfo?.description || "A curated collection of automotive excellence.";

  // Header background logic
  const headerBg = categoryId === 'lemans-2025' 
    ? 'https://images.unsplash.com/photo-1596707328604-927508493021?q=80&w=2070&auto=format&fit=crop'
    : 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?q=80&w=2070&auto=format&fit=crop'; // Vintage default

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-screen flex items-center justify-center bg-background text-red-500">
        Failed to load photos. Please try again later.
      </div>
    );
  }

  const isEmpty = !photos || photos.length === 0;

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Category Header */}
      <div className="relative h-[40vh] min-h-[400px] flex items-end pb-12 mb-12">
        <div 
          className="absolute inset-0 bg-cover bg-center fixed-bg"
          style={{ backgroundImage: `url('${headerBg}')` }}
        >
          <div className="absolute inset-0 bg-black/60" />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary font-bold uppercase tracking-widest text-sm mb-4 block">
              Collection
            </span>
            <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-4">
              {title}
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl font-light">
              {description}
            </p>
          </motion.div>
        </div>
      </div>

      {/* Gallery Grid */}
      <div className="container mx-auto px-4">
        {isEmpty ? (
          <div className="text-center py-24 border border-dashed border-white/10 rounded-lg">
            <Camera className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-display text-white mb-2">No photos found</h3>
            <p className="text-gray-400">This gallery is currently being curated. Check back soon.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 auto-rows-fr">
            {photos.map((photo, i) => (
              <PhotoCard 
                key={photo.id} 
                photo={photo} 
                index={i}
                onClick={() => setIndex(i)} 
              />
            ))}
          </div>
        )}
      </div>

      <Lightbox
        open={index >= 0}
        index={index}
        close={() => setIndex(-1)}
        slides={photos?.map(p => ({ src: p.url, title: p.title, description: p.description })) || []}
      />
    </div>
  );
}
