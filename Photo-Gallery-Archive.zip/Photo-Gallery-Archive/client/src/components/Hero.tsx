import { motion } from "framer-motion";
import { Link } from "wouter";
import { ChevronRight } from "lucide-react";

export function Hero() {
  return (
    <section className="relative h-screen min-h-[600px] flex items-center overflow-hidden">
      {/* Background Image - High quality Unsplash racing image */}
      {/* 24h Le Mans style night racing */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat z-0"
        style={{ 
          backgroundImage: `url('https://pixabay.com/get/gac49846d02a3f51ce444f0f8e234e11a411bdd7452540c59fa32acd96149f472dd054a04ff4b047bad7da676cf35d4cb026200988cdfc78497c8fc0746e750b8_1280.jpg')`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/30" />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <div className="container mx-auto px-4 relative z-10 pt-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-4xl"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 border border-primary/30 rounded-full bg-primary/10 backdrop-blur-sm mb-6">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-xs font-bold tracking-widest uppercase text-primary">Now Booking 2026 Season</span>
          </div>

          <h1 className="text-5xl md:text-7xl lg:text-9xl font-display font-bold text-white leading-none mb-6">
            CAPTURE THE <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-orange-500">
              ADRENALINE
            </span>
          </h1>

          <p className="text-lg md:text-xl text-gray-300 max-w-xl mb-10 leading-relaxed font-light">
            Specialized automotive photography for the world's most prestigious endurance races and classic car exhibitions.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/gallery/lemans-2025" className="group relative px-8 py-4 bg-primary text-white font-bold uppercase tracking-widest overflow-hidden">
              <span className="relative z-10 flex items-center gap-2">
                Le Mans 2025 <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-white transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300 mix-blend-screen" />
            </Link>
            
            <Link href="/gallery/retromobile-2026" className="group px-8 py-4 border border-white/20 text-white font-bold uppercase tracking-widest hover:bg-white/5 transition-colors">
              Rétromobile 2026
            </Link>
          </div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div 
        className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/50 flex flex-col items-center gap-2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <span className="text-[10px] uppercase tracking-widest">Scroll</span>
        <div className="w-[1px] h-12 bg-gradient-to-b from-white/50 to-transparent" />
      </motion.div>
    </section>
  );
}
