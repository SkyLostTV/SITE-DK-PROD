import { motion } from "framer-motion";
import { Photo } from "@shared/schema";
import { Eye, MapPin } from "lucide-react";

interface PhotoCardProps {
  photo: Photo;
  onClick: () => void;
  index: number;
}

export function PhotoCard({ photo, onClick, index }: PhotoCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      viewport={{ once: true }}
      className="group relative cursor-pointer overflow-hidden rounded-sm bg-muted aspect-[3/2]"
      onClick={onClick}
    >
      <img
        src={photo.url}
        alt={photo.title}
        className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110 group-hover:brightness-110"
        loading="lazy"
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
          <h3 className="text-lg font-display font-bold text-white mb-1 uppercase tracking-wide">
            {photo.title}
          </h3>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-primary text-xs font-bold uppercase tracking-wider">
              <MapPin className="w-3 h-3" />
              <span>{photo.location}</span>
            </div>
            <button className="p-2 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-sm transition-colors text-white">
              <Eye className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
