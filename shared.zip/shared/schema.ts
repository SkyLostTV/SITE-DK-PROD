import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const photos = pgTable("photos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  url: text("url").notNull(),
  category: text("category").notNull(), // 'lemans-2025' | 'retromobile-2026'
  location: text("location"),
  capturedAt: timestamp("captured_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPhotoSchema = createInsertSchema(photos).omit({ 
  id: true, 
  createdAt: true 
});

export type Photo = typeof photos.$inferSelect;
export type InsertPhoto = z.infer<typeof insertPhotoSchema>;

export const categories = [
  { id: 'lemans-2025', name: '24h Le Mans 2025', description: 'The ultimate endurance race.' },
  { id: 'retromobile-2026', name: 'Rétromobile 2026', description: 'Classic cars and automotive history.' }
] as const;
